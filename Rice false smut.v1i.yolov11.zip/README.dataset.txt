# Rice false smut > 2023-08-01 8:46am
https://universe.roboflow.com/liulei-hcdye/rice-false-smut

Provided by a Roboflow user
License: Public Domain

